Rails.application.routes.draw do
  resources :developers
  if Rails.env.development?
    mount LetterOpenerWeb::Engine, at: "/letter_opener"
  end

  mount_devise_token_auth_for 'User', at: 'auth', controllers: {
    sessions:  'sessions'
  }

  resources :questions, except: :new do
    resource :answer, only: [:update, :destroy]
  end
  resources :groups, except: :new
  resources :categories, except: :new
end
