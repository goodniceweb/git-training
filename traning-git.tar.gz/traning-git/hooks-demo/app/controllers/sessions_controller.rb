require 'json_web_token'

class SessionsController < DeviseTokenAuth::ApplicationController
  skip_before_action :verify_authenticity_token

  def create
    if params[:uuid].present? && params[:token].present?
      binding.pry
      developer = Developer.where(uid: params[:uid]).first
      token = params[:token]
      if JsonWebToken.valid?(token)
        render json: user, token: token
      else
        head :no_content
      end
    else
      user = User.where(email: params[:email]).first
      user = sign_in(:user, user)
      token = JsonWebToken.encode(user_id: user.id)
      render json: user, token: token
    end
  end
end
