class GroupsController < ApplicationController
  before_filter :set_group, except: [:index, :create]

  def index
    render json: Group.all
  end

  def show
    render json: @group
  end

  def edit
    render json: @group
  end

  def create
    @group = Group.create(group_params)

    if @group.persisted?
      render json: @group, status: :ok
    else
      render json: @group.errors, status: :unprocessable_entity
    end
  end

  def update
    if @group.update(group_params)
      render json: @group, status: :ok
    else
      render json: @group.errors, status: :unprocessable_entity
    end
  end

  def destroy
    @group.destroy
    render json: @group
  end

  private

  def set_group
    @group = Group.find(params[:id])
  end

  def group_params
    params.permit(:name)
  end
end
