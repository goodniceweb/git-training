require 'json_web_token'

class ApplicationController < ActionController::Base
  include DeviseTokenAuth::Concerns::SetUserByToken
  # Prevent CSRF attacks by raising an exception.
  # For APIs, you may want to use :null_session instead.
  protect_from_forgery with: :null_session

  private

  # USAGE: paste line below in every single controller you wanna have auth before
  # before_filter :verify_jwt_token, only: :create
  def verify_jwt_token
    head :unauthorized if authorization_header?
  end

  def authorization_header?
    request.headers['Authorization'].nil? ||
      !JsonWebToken.valid?(request.headers['Authorization'].split(' ').last)
  end
end
