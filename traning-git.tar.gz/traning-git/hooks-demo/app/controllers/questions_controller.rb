class QuestionsController < ApplicationController
  before_filter :set_question, except: [:index, :create]
  # before_filter :verify_jwt_token, only: :create

  def index
    json = QuestionPaginatorService.new(params).run

    render json: json
  end

  def show
    render json: @question
  end

  def create
    @question = Creator::Question.create(question_params)

    if @question.persisted?
      render json: @question, status: :ok
    else
      render json: @question.errors, status: :unprocessable_entity
    end
  end

  def update
    if @question.update(question_params)
      render json: @question, status: :ok
    else
      render json: @question.errors, status: :unprocessable_entity
    end
  end

  def destroy
    @question.destroy
    render json: @question
  end

  private

  def set_question
    @question = Question.find(params[:id])
  end

  def question_params
    params.permit(
      :title, :description, :difficult, :importance, :deadline,
      :category_id, :category, :owner_id, :owner_type, :category,
      :answer
    )
  end
end
