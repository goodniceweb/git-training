class AnswersController < ApplicationController
  before_filter :set_answer, except: [:index, :create]

  def update
    if @answer.update(answer_params)
      render json: @answer, status: :ok
    else
      render json: @answer.errors, status: :unprocessable_entity
    end
  end

  def destroy
    @answer.destroy
    render json: @answer
  end

  private

  def set_answer
    @answer = Question.find(params[:question_id]).answer
  end

  def answer_params
    params.permit(:text, :fake)
  end
end
