class CategoriesController < ApplicationController
  before_filter :set_category, except: [:index, :create]

  def index
    categories = Category.all.map do |c|
      { text: c.name, id: c.id }
    end

    render json: categories
  end

  def show
    render json: @category
  end

  def edit
    render json: @category
  end

  def create
    @category = Category.create(category_params)

    if @category.persisted?
      render json: @category, status: :ok
    else
      render json: @category.errors, status: :unprocessable_entity
    end
  end

  def update
    if @category.update(category_params)
      render json: @category, status: :ok
    else
      render json: @category.errors, status: :unprocessable_entity
    end
  end

  def destroy
    @category.destroy
    render json: @category
  end

  private

  def set_category
    @category = Category.find(params[:id])
  end

  def category_params
    params.permit(:name, :parent_id)
  end
end
