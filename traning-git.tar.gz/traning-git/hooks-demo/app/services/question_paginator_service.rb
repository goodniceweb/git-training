class QuestionPaginatorService
	QUESTIONS_COUNT = 10

	attr_reader :page_number, :page_count, :questions
	attr_accessor :quesions_per_page

	def initialize(params = {})
		@page_number = (params[:pageNumber] || 1).to_i
		@category_id = params[:categoryId]
		@quesions_per_page = params[:quesions_per_page] || QUESTIONS_COUNT
	end

	def run
		@page_count = questions_count / QUESTIONS_COUNT
		@page_count = 1 if @page_count < 1
		@page_number = 1 if @page_number > @page_count
		@questions = get_questions

		get_json
	end

	def get_json
		{
      questions: @questions,
      page_count: @page_count,
      page_number: @page_number,
			category_id: @category_id
    }
	end

	private

	def questions_count
		if @category_id
      Question.joins(:category).where('categories.id = ?', @category_id).count
    else
      Question.count
    end
	end

	def get_questions
		offset =
			@page_count < @page_number ? 0 : @quesions_per_page * (@page_number - 1)

	  if @category_id.present?
	  	category = Category.find(@category_id)
      category.questions.offset(offset).take(@quesions_per_page)
    else
      Question.offset(offset).take(@quesions_per_page)
    end
	end
end
