module Creator
  class Question
    class << self
      def create(options = {})
        new(options).create
      end
    end

    attr_reader :category, :title, :answer, :importance, :difficult, :owner_id

    # TODO: add tags, and maybe description??
    def initialize(options = {})
      @category   = options[:category] or raise ArgumentError.new("Missing category")
      @title      = options[:title]    or raise ArgumentError.new("Missing title")
      @answer     = options[:answer]   or raise ArgumentError.new("Missing answer")
      @importance = options[:importance] || 5
      @difficult  = options[:difficult]  || 5
      @owner_id   = options[:owner_id]
    end

    def create
      question = nil
      ::Question.transaction do
        # category_instance = Category.where(name: category).first_or_create
        category_instance = Category.find category # for now we have category_id in category field
        user = User.where(id: owner_id).first
        question_attributes = {
          title: title,
          importance: importance,
          difficult: difficult,
          category: category_instance
        }
        question_attributes.merge!(owner: user) if user.present?
        question = ::Question.create(question_attributes)
        Answer.create(text: answer, question: question)
        # ad.tags << tags.map do |tag|
        #   Tag.where(name: tag).first_or_create
        # end
      end
      question
    end
  end
end
