class Developer < ActiveRecord::Base
end
