class Quiz < ActiveRecord::Base
  has_many :quiz_items, dependent: :destroy
  
  validates :name, presence: true
end
