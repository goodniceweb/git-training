class Tag < ActiveRecord::Base
  has_many :taggables
  has_many :categories, through: :taggables
  has_many :questions, through: :taggables
  has_many :groups, through: :taggables
end
