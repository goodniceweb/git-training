class Taggable < ActiveRecord::Base
  belongs_to :tag
  belongs_to :category
  belongs_to :question
  belongs_to :group
end
