class QuizItem < ActiveRecord::Base
  belongs_to :question
  belongs_to :quiz

  validates :question, presence: true
  validates :quiz, presence: true
end
