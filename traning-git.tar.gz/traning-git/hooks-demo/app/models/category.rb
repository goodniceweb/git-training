class Category < ActiveRecord::Base
  belongs_to :parent, class_name: 'Category'
  has_many :taggables
  has_many :tags, through: :taggables
  has_many :questions

  validates :name, presence: true
end
