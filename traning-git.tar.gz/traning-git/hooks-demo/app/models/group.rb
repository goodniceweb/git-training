class Group < ActiveRecord::Base
  has_many :questions, as: :owner
  has_many :user_groups, dependent: :destroy

  validates :name, presence: true
end
