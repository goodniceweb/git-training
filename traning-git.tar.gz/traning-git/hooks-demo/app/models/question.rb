class Question < ActiveRecord::Base
  belongs_to :category
  belongs_to :owner, polymorphic: true
  has_one :answer, dependent: :destroy
  has_many :hints, dependent: :destroy
  has_many :taggables
  has_many :tags, through: :taggables
  has_many :quiz_items, dependent: :destroy

  validates :title, presence: true
  validates :difficult, numericality: { only_integer: true }
  validates :importance, numericality: { only_integer: true }
  validates :owner_type, inclusion: { in: %w(User Group) }, allow_nil: true
end
