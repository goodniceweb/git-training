class AnswerSerializer < ActiveModel::Serializer
  attributes :id, :text, :fake
end
