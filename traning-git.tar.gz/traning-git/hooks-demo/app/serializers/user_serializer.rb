class UserSerializer < ActiveModel::Serializer
  attributes :id, :uid, :first_name, :last_name, :email, :provider, :token

  def token
    serialization_options[:token]
  end
end
