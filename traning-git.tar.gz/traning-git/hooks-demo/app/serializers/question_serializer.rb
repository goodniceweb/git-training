class QuestionSerializer < ActiveModel::Serializer
  attributes :id, :title, :description,
    :difficult, :importance, :deadline,
    :created_at, :updated_at

  has_one :category
  has_one :owner
  has_one :answer
  has_many :tags
end
