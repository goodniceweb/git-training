class CreateQuestions < ActiveRecord::Migration
  def change
    create_table :questions do |t|
      t.string :title
      t.text :description
      t.integer :difficult
      t.integer :importance
      t.datetime :deadline
      t.integer :category_id
      t.integer :owner_id
      t.string :owner_type

      t.timestamps null: false
    end

    add_index :questions, :category_id
    add_index :questions, [:owner_id, :owner_type]
  end
end
