class CreateQuizItems < ActiveRecord::Migration
  def change
    create_table :quiz_items do |t|
      t.integer :question_id
      t.integer :quiz_id
      t.string :state
      t.time :duration

      t.timestamps null: false
    end
    
    add_index :quiz_items, :question_id
    add_index :quiz_items, :quiz_id
  end
end
