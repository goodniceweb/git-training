class CreateTaggables < ActiveRecord::Migration
  def change
    create_table :taggables do |t|
      t.integer :tag_id
      t.integer :category_id
      t.integer :question_id
      t.integer :group_id

      t.timestamps null: false
    end
    
    add_index :taggables, :tag_id
    add_index :taggables, :category_id
    add_index :taggables, :question_id
    add_index :taggables, :group_id
  end
end
