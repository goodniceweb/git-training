class CreateHints < ActiveRecord::Migration
  def change
    create_table :hints do |t|
      t.integer :question_id
      t.text :text

      t.timestamps null: false
    end
    
    add_index :hints, :question_id
  end
end
