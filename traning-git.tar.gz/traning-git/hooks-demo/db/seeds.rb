require 'faker'

puts 'Start'
10.times do
  category = Category.create(name: Faker::Name.title)
  group = Group.create(name: Faker::Name.title)

  10.times do
    question = Question.create(
      title: Faker::Lorem.sentence,
      description: Faker::Lorem.paragraph,
      category: category,
      owner: group,
      difficult: 1,
      importance: 1,
      deadline: Date.tomorrow
    )

    Answer.create(question: question, text: Faker::Lorem.paragraph)
  end
end
puts 'Complete'
