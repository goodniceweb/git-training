require 'jwt'

class JsonWebToken
  class << self
    def encode(payload, expiration = 24.hours.from_now)
      payload = payload.dup
      payload['exp'] = expiration.to_i
      JWT.encode(payload, Rails.application.secrets.secret_key_base)
    end

    def decode(token)
      JWT.decode(token, Rails.application.secrets.secret_key_base).first
    end
    
    def valid?(token)
      begin
        decode(token)
      rescue
        false
      end
    end
  end
end
